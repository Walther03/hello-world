package pe.com.equifax;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import net.minidev.json.JSONArray;
import pe.com.equifax.bus.BusConsulta;
import pe.com.equifax.bus.util.UtilFile;
import pe.com.equifax.bus.util.UtilString;


@SpringBootApplication
public class App implements CommandLineRunner {

	private static Logger log = LoggerFactory.getLogger(App.class);
	
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	@Value("${file.path.mapper}")
	String fileMapper;
	
	@Value("${file.path.input}")
	String fileIn;

	@Value("${file.path.mapper}")
	String canCallSmarts;

	
	@Value("${file.path.inputSmart}")
	private String fileInputSmart;

	@Autowired
	BusConsulta busConsulta;

	@Override
	public void run(String... strings) throws Exception {
		
    	File directory = new File(fileIn);
    	String jsonModel = UtilFile.leerArchivo(fileInputSmart);
    	log.info("JsonModel:"+jsonModel);
    	
      	for (final File fileEntry : directory.listFiles()) {
			if(fileEntry.getName().endsWith(".json")) {
				Map<String, String> map = new HashMap<String, String>();
				String [] constwrapper = null;
				String ruta =fileIn +fileEntry.getName();
				
				String[] objetc = fileEntry.getName().split("_"); 
				String tipoDoc = objetc[0].toString();
				String numDoc = objetc[1].toString();
				numDoc = numDoc.substring(1, numDoc.length()-5);
				
				ArrayList<String> mapper = UtilFile.leerMapper(fileMapper);
				String tramain = UtilFile.leerArchivo(ruta);
				
				/*********************************
				String tramaPrimary = UtilString.obtenerPrimary(tramain, numDoc);
				if (tramaPrimary.equals(""))tramaPrimary = tramain;
				***************************************************/
								
				for(String constante:mapper) {
					constwrapper = constante.split(",");
					map.put(constwrapper[1], UtilString.obtenerValor(tramain, constwrapper[0], tipoDoc, numDoc));
					//map.put(constwrapper[1], UtilString.obtenerValor(tramaPrimary, constwrapper[0], tipoDoc, numDoc));
				}
				if(map.size()>0) {
					busConsulta.reemplazarVariables(map, jsonModel, numDoc);	
				}else {
					log.info("Doc:" + numDoc + "Error en Response");
				}
			}
			else {
				fileEntry.delete();
			}
	    }
    	
	}
	

}
