package pe.com.equifax.bus;


import java.util.Map;
import org.springframework.stereotype.Component;


@Component
public interface BusConsulta {
	public void reemplazarVariables (Map<String, String> values,String columnOne, String numDoc);
	
}
