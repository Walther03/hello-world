package pe.com.equifax.bus.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import pe.com.equifax.bus.BusConsulta;
import pe.com.equifax.smart.SmartsService;

@Component
public class BusConsultaImpl implements BusConsulta {

	private static Logger log = LoggerFactory.getLogger(BusConsultaImpl.class);
	
	
	@Value("${file.path.mapper}")
	String fileMapper;
	
	@Value("${file.path.input}")
	String fileIn;

	@Value("${file.path.output}")
	private String fileOut;

	@Value("${url.smart}")
	private String urlBase;
	
	public final SmartsService smartsService = null;
	
	@Override
	public void reemplazarVariables(Map<String, String> values, String columnOne, String numDoc) {

		Configuration config = Configuration.builder().options(Option.DEFAULT_PATH_LEAF_TO_NULL).build();
		
		columnOne = JsonPath.using(config).parse(columnOne).set("$.personalInformation.peruIdNumber",numDoc).jsonString();
		
		try {
		
			for (String cabecera : values.keySet()) {
				if(values.get(cabecera)!=null) {
					if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer."+cabecera) != null) columnOne = JsonPath.using(config).parse(columnOne).set("$.pedsconsumer."+cabecera,values.get(cabecera)).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer.aditionalData.tmEquifax."+cabecera) != null) columnOne=JsonPath.using(config).parse(columnOne).set("$.pedsconsumer.aditionalData.tmEquifax."+cabecera,values.get(cabecera)).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer.aditionalData.externalData."+cabecera) != null) columnOne=JsonPath.using(config).parse(columnOne).set("$.pedsconsumer.aditionalData.externalData."+cabecera,values.get(cabecera)).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.attributes.predictors."+cabecera) != null) 
						columnOne=JsonPath.using(config).parse(columnOne).set("$.attributes.predictors."+cabecera,values.get(cabecera)).jsonString();	
				}else {
					if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer."+cabecera) != null) columnOne = JsonPath.using(config).parse(columnOne).delete("$.pedsconsumer."+cabecera).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer.aditionalData.tmEquifax."+cabecera) != null) columnOne=JsonPath.using(config).parse(columnOne).delete("$.pedsconsumer.aditionalData.tmEquifax."+cabecera).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.pedsconsumer.aditionalData.externalData."+cabecera) != null) columnOne=JsonPath.using(config).parse(columnOne).delete("$.pedsconsumer.aditionalData.externalData."+cabecera).jsonString();
					else if(JsonPath.using(config).parse(columnOne).read("$.attributes.predictors."+cabecera) != null) columnOne=JsonPath.using(config).parse(columnOne).delete("$.attributes.predictors."+cabecera).jsonString();
				}
				
			}
			saveRecord(numDoc+",\""+columnOne.replace("\"", "\"\"")+"\"");
//			ResponseEntity<String> response =consultaclient(columnOne);
//			saveRecord(consultaclient2(columnOne));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveRecord(String pJson) throws IOException {
		BufferedWriter bw = null;
		FileWriter fw = null;
		String lineBreak = pe.com.equifax.bus.util.ConstantDF.LINE_BREAK;
		if (pJson!=null) {
			try {
				File file = new File(fileOut);
				// if file doesnt exists, then create it
				if (!file.exists()) {
					file.createNewFile();
				}
				fw = new FileWriter(file.getAbsoluteFile(), true); 
				bw = new BufferedWriter(fw);
				bw.write(pJson+lineBreak);
			} catch (IOException e) {
				log.error("IOException error " + e);
			} finally {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			}
		} else {
			log.error("Este documento no se puede guardar...");
		}
		
	}
	
	
	private ResponseEntity<String> consultaclient(String requestSmart) {
		Map<String, Object> request;
		ResponseEntity<String> result=null;
		try {
			request = new ObjectMapper().readValue(requestSmart, HashMap.class);
			Map<String, Object> headerMap = new HashMap<>();
			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization", "Basic UEVfTUlHUkFDSU9OX0lDNjptWDd3UWVCRQ==");
			result = smartsService.postSmarts(request, headerMap);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	private String consultaclient2(String pJson) {
		String strResponse =null;
		BufferedReader in= null;
		HttpURLConnection con=null;
		DataOutputStream wr=null;
		InputStreamReader inputStream=null;
		
		try {
			URL url = new URL(urlBase);
			
			// add request header
			con = (HttpsURLConnection) url.openConnection();
			
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "pplication/json");
			con.setRequestProperty("Authorization", "Basic UEVfTUlHUkFDSU9OX0lDNjptWDd3UWVCRQ==");
			// Send post request
			con.setDoOutput(true);
			
			wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(pJson);
			wr.flush();
			wr.close();
			
			inputStream= new InputStreamReader(con.getInputStream());
			in = new BufferedReader(inputStream);
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			int status = con.getResponseCode();
			 strResponse = response.toString();
			
		}catch(Exception e) {
			log.error("Error: " + e);
			log.info("Client Caído");
			return null;
		}finally{
			if(in!=null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}			
			if(inputStream!=null){
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(con!=null){
				con.disconnect();
			}
			if(wr!=null){
				try {
					wr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return strResponse;
	}

}
