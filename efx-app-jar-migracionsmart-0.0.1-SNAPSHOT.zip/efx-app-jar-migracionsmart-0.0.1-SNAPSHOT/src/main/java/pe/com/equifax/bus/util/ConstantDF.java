package pe.com.equifax.bus.util;

import org.springframework.stereotype.Component;

@Component
public class ConstantDF {
	public static final String LINE_BREAK = "\n";
	public static final String EMPTY = "";
	public static final String DIV = "|";
}
