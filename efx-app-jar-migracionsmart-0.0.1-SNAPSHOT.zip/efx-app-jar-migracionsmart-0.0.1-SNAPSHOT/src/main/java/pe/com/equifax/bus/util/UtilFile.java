package pe.com.equifax.bus.util;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileReader;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class UtilFile {
	
	private static final Logger log = LoggerFactory.getLogger(UtilFile.class);
	
	public static String getFileResponse(String tip, String num, String nameFolder) {
		String response = "";
		// PARA LECTURA DE ARCHIVO
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		try {
			archivo = new File(nameFolder+"\\"+tip+"_"+num+".json");
			if (archivo.exists()) {
				fr = new FileReader(archivo);
				br = new BufferedReader(fr);
				
				String linea;
				while ((linea = br.readLine()) != null) {
					response = response + linea.trim();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// En el finally cerramos el fichero, para asegurarnos
			// que se cierra tanto si todo va bien como si salta
			// una excepcion.
			try {
				if (null != fr) {fr.close();}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return response;
	}
	
	public static String getDate() {
		return new SimpleDateFormat("yyyyMMdd HHmmss").format(new Date());
	}
	
	public static void createDirectory(String name) {
		name = name.replace("\\", "/");
		String paths[] = name.split("/");
		String directory = ""; 
		for(int i=0;i<paths.length;i++) {
			directory = directory + "/" + paths[i];
			File directorio=new File(directory);
			directorio.mkdir();
		}
	} 
	
	public static ArrayList<String> leerMapper(String ruta) {
		List<String> listaDatos = new ArrayList<String>();
		File file = new File(ruta);
		
		try {
			if(file.isFile()) {
				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String linea = scanner.nextLine();
					listaDatos.add(linea);
				}
				scanner.close();
			}else {
				log.warn("No se pudo encontrar el archivo especificado " + ruta);
			}
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return (ArrayList<String>) listaDatos;
	}
	
	public static String leerArchivo(String ruta) {
		String listaDatos = null;
		File file = new File(ruta);
		
		try {
			if(file.isFile()) {
				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					listaDatos = scanner.nextLine();
				}
				scanner.close();
			}else {
				log.warn("No se pudo encontrar el archivo especificada " + ruta);
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return listaDatos;
	}
	
}
