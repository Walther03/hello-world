package pe.com.equifax.bus.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import net.minidev.json.JSONArray;


public class UtilString {
	
	static Configuration config = Configuration.builder().options(Option.DEFAULT_PATH_LEAF_TO_NULL).build();
	private static final Logger log = LoggerFactory.getLogger(UtilString.class);
	
	public static String obtenerValor(String trama, String constante,  String tipoDoc, String numDoc) {
		
		constante = constante.toUpperCase() + "=";
		String valor = null;
		
		if(trama.indexOf(constante) > 0) {
			
			int indexInicial = trama.indexOf("PLATORIG");
			int indexFinal = trama.indexOf("\"}]", indexInicial);
			String cadena = trama.substring(indexInicial, indexFinal);
			
			int idx_i = cadena.indexOf(constante) + constante.length();
			int idx_f = cadena.indexOf("|", idx_i);
			
			if(idx_f < 0) {
				valor = cadena.substring(idx_i);
			}else {
				valor = cadena.substring(idx_i, idx_f);
			}
			if(valor.equals("null")) {
				log.info("hay valor null: "+ tipoDoc + "_" + numDoc + ".json" );
			}
		}else {
//			log.warn(constante + " no se encuentra la trama " + tipoDoc + "_" + numDoc + ".json");
		}

		return valor;
	}
	
	public static String obtenerPrimary(String tramain, String numDoc) {
		String tramaPrimary = "";
		
		JSONArray jsonArray = JsonPath.read(tramain, "$.consumerSubjects.consumerSubject[*]");
		
		try {
			for (int i=0; i<jsonArray.size(); i++) {
				if(JsonPath.using(config).parse(tramain).read("$.consumerSubjects.consumerSubject["+i+"].subjectIdentifier") != null) {
					if(JsonPath.using(config).parse(tramain).read("$.consumerSubjects.consumerSubject["+i+"].subjectIdentifier").toString().equals("PRIMARY")) {
						tramaPrimary = JsonPath.using(config).parse(tramain).read("$.consumerSubjects.consumerSubject["+i+"]").toString();
						break;
					}
				}
			}
		}
		catch(Exception e) {
			System.out.println("Error en la trama consumerSubjects -->" + numDoc );
		}
		
		return tramaPrimary;
	}
}
