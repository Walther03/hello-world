package pe.com.equifax.modelo;

public class RequestSmart {
	int tipoDoc;
	String numDoc;
	
	public RequestSmart() {
		// TODO Auto-generated constructor stub
	}

	public int getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(int tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}
	
	

}
