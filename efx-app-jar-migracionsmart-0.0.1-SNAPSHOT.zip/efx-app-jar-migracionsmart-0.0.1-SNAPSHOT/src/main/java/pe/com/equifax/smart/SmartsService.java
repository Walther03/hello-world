package pe.com.equifax.smart;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Component
@FeignClient(name="SmartsService", url="${url.smart}",fallbackFactory=SmartsService.class)
public interface SmartsService {

	@PostMapping(value="",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> postSmarts(@RequestBody Map<String,Object> request,
			@RequestHeader Map<String, Object> headerMap);


}
