package pe.com.equifax.smart.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import feign.hystrix.FallbackFactory;
import pe.com.equifax.smart.SmartsService;


@Component
public class SmartsServiceFallbackFactory  implements FallbackFactory<SmartsService> {
	private static Logger log = LoggerFactory.getLogger(SmartsServiceFallbackFactory.class);
	
	@Override
	public SmartsService create(Throwable cause) {
		return new SmartsService() {
			
			@Override
			public ResponseEntity<String> postSmarts(Map<String,Object> request, Map<String, Object> headerMap){
				log.warn("An error occurred while consuming the ps service with the following error : {}",
						cause.getMessage());
				return new ResponseEntity<>("",HttpStatus.SERVICE_UNAVAILABLE);
			}
		};
	}
}
